"""Implements a variety of regularization techniques for NN weights."""
