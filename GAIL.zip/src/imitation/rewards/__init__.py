"""Reward models: neural network modules, serialization, preprocessing, etc."""
