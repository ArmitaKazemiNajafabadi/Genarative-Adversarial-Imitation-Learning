---
name: Bug report
about: Create a report to help us improve
title: ''
labels: bug
assignees: ''

---

## Bug description
Description of what the bug is.

## Steps to reproduce
Code or a description of how to reproduce the bug.

## Environment
- Operating system and version:
- Python version:
- Output of `pip freeze --all`:
