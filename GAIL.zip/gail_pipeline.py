"""
GAIL Pipeline using HumanCompatibleAI/imitation library.
Supports vector-based observation environments with pre-trained experts.
"""
import os
import sys
import argparse
import numpy as np
import gymnasium as gym
from pathlib import Path
from stable_baselines3 import PPO
from stable_baselines3.common.evaluation import evaluate_policy
from stable_baselines3.ppo import MlpPolicy
from imitation.algorithms.adversarial.gail import GAIL #
from imitation.data import rollout
from imitation.data.wrappers import RolloutInfoWrapper #
from imitation.policies.serialize import load_policy
from imitation.rewards.reward_nets import BasicRewardNet #
from imitation.util.networks import RunningNorm
from imitation.util.util import make_vec_env

import warnings
warnings.filterwarnings("ignore")

# ready-to-use-environments : continuous state-space and descrete action-space 
# Environmen mapping for SEALS pre-trained experts
SEALS_ENV_MAP = {
    "CartPole-v0": "seals:seals/CartPole-v0",
    "MountainCar-v0": "seals:seals/MountainCar-v0",      
    "LunarLander-v2": "seals:seals/LunarLander-v2",
    # add an environment as your choice
}

EXPERT_MAP = {
    "CartPole-v0": "seals-CartPole-v0",
    "MountainCar-v0": "seals-MountainCar-v0",           
    "LunarLander-v2": "seals-LunarLander-v2",
    # add exper names based on their environment
}


class GAILPipeline:
    """End-to-end GAIL pipeline for imitation learning."""
    
    def __init__(self, env_name: str, seed: int = 42, n_envs: int = 8):
        self.env_name = env_name
        self.seed = seed
        self.n_envs = n_envs
        self.expert = None
        self.rollouts = None
        self.learner = None
        self.gail_trainer = None
        self.venv = None
        
    def setup_environment(self):
        """Create vectorized environment with rollout wrapper."""
        print(f"[1/4] Setting up environment: {self.env_name}")
        
        env_id = SEALS_ENV_MAP.get(self.env_name, self.env_name)

        # Create vectorized environment for parallel training
        self.venv = make_vec_env(
            env_id,
            rng=np.random.default_rng(self.seed),
            n_envs=self.n_envs,
            post_wrappers=[lambda env, _: RolloutInfoWrapper(env)], # Wrapper to track episode info for rollout collection
        )
        print(f"  -> Environment ready: {env_id} ({self.n_envs} parallel envs)")
        return self.venv
    
    def load_expert(self):
        """Load pre-trained expert policy from HuggingFace."""
        print(f"[2/4] Loading expert policy from HuggingFace")
        
        if self.venv is None:
            raise ValueError("Environment not set up. Run setup_environment() first.")
        
        expert_name = EXPERT_MAP.get(self.env_name)
        if expert_name is None:
            raise ValueError(
                f"No pre-trained expert for {self.env_name}. "
                f"Available: {list(EXPERT_MAP.keys())}"
            )
        
        self.expert = load_policy(
            "ppo-huggingface",
            organization="HumanCompatibleAI",
            env_name=expert_name,
            venv=self.venv,
        )
        
        expert_rewards, _ = evaluate_policy(
            self.expert, self.venv, n_eval_episodes=100, return_episode_rewards=True
        )
        mean_reward = np.mean(expert_rewards)
        std_reward = np.std(expert_rewards)
        
        print(f"  -> Expert loaded | Mean reward: {mean_reward:.2f} ± {std_reward:.2f}")
        return self.expert
    
    def collect_demonstrations(self, n_episodes: int = 60):
        """Collect expert demonstrations."""
        print(f"[3/4] Collecting {n_episodes} expert demonstrations")
        
        if self.expert is None:
            raise ValueError("Expert not loaded. Run load_expert() first.")
        
        # Collect expert demonstrations by rolling out the expert policy
        self.rollouts = rollout.rollout(
            self.expert,
            self.venv,
            rollout.make_sample_until(min_episodes=n_episodes),
            rng=np.random.default_rng(self.seed), 
        )
        
        total_transitions = sum(len(r.obs) for r in self.rollouts)
        print(f"  -> Collected {len(self.rollouts)} episodes, {total_transitions} transitions")
        return self.rollouts
    
    def setup_gail(self, learner_config: dict = None, gail_config: dict = None):
        """Initialize GAIL trainer with learner and reward network."""
        print("[4/4] Setting up GAIL trainer")
        
        if self.rollouts is None:
            raise ValueError("No demonstrations. Run collect_demonstrations() first.")
        
        # PPO learner hyperparameters (student policy that learns to imitate expert)
        if learner_config is None:
            learner_config = {
                "batch_size": 64,           # Number of samples per PPO update
                "ent_coef": 0.0,            # Entropy coefficient (0 = no exploration bonus)
                "learning_rate": 4e-4,      # Step size for policy gradient updates
                "gamma": 0.95,              # Discount factor for future rewards
                "n_epochs": 5,              # Number of epochs per PPO update
            }
            
        # GAIL trainer hyperparameters (adversarial training setup)
        if gail_config is None: 
            gail_config = {
                "demo_batch_size": 2048,                # Expert samples per discriminator update
                "gen_replay_buffer_capacity": 512,      # Buffer size for learner experience
                "n_disc_updates_per_round": 16,          # Discriminator training steps per round
            }

        # Initialize PPO learner (untrained policy that will learn via GAIL)
        self.learner = PPO(
            env=self.venv,              # Environment to train in
            policy=MlpPolicy,           # Multi-layer perceptron policy network
            seed=self.seed,             # Random seed for weight initialization
            verbose=0,                  # Suppress PPO training logs (?)
            **learner_config,           # Unpack PPO hyperparameters
        )

        
        # Create discriminator reward network (distinguishes expert from learner)
        reward_net = BasicRewardNet(
            observation_space=self.venv.observation_space,
            action_space=self.venv.action_space,
            normalize_input_layer=RunningNorm,                  # Normalize inputs for stable training
        )

        # Initialize GAIL trainer (adversarial imitation learning)
        self.gail_trainer = GAIL(
            demonstrations=self.rollouts,   # Expert trajectories to imitate
            venv=self.venv,                 # Environment for generating learner trajectories
            gen_algo=self.learner,          # Generator (learner policy to train)
            reward_net= reward_net,         # Discriminator (reward network)
            **gail_config,                  # Unpack GAIL hyperparameters
        )

        
        # Calculate minimum training timesteps required (prevents errors)
        min_timesteps = (
        gail_config["demo_batch_size"]              
        * gail_config["n_disc_updates_per_round"]
        )
        print(f"  -> GAIL trainer initialized")
        print(f"  → Minimum training timesteps: {min_timesteps}")
        return self.gail_trainer
    
    def train_gail(self, total_timesteps: int = 200000):
        """Train using GAIL."""
        print(f"\nTraining GAIL ({total_timesteps} steps)")
        print("="*60)
        
        if self.gail_trainer is None:
            raise ValueError("GAIL not set up. Run setup_gail() first.")
        
        mean_before, std_before = evaluate_policy(
            self.learner, self.venv, n_eval_episodes=20
        )
        print(f"Learner reward before: {mean_before:.2f} ± {std_before:.2f}")

        suppress_prints()
        print(f"\nTraining for {total_timesteps} timesteps...")
        self.gail_trainer.train(total_timesteps)
        enable_prints()
        
        mean_after, std_after = evaluate_policy(
            self.learner, self.venv, n_eval_episodes=20
        )
        
        print(f"\nLearner reward after: {mean_after:.2f} ± {std_after:.2f}")
        print(f"Improvement: {mean_after - mean_before:+.2f}")
        print("="*60)
        
        return {
            "before": (mean_before, std_before),
            "after": (mean_after, std_after),
            "improvement": mean_after - mean_before,
        }
    
    def run_full_pipeline(
        self,
        n_demo_episodes: int = 60,
        gail_timesteps: int = 200000,
        learner_config: dict = None,
        gail_config: dict = None,
    ):
        """Run complete GAIL pipeline end-to-end."""
        self.setup_environment()
        self.load_expert()
        self.collect_demonstrations(n_episodes=n_demo_episodes)
        self.setup_gail(learner_config=learner_config, gail_config=gail_config)
        results = self.train_gail(total_timesteps=gail_timesteps)
        
        print("\n" + "="*60)
        print("Pipeline complete!")
        print("="*60)
        return results

    
def suppress_prints():
    sys.stdout = open(os.devnull, 'w')

def enable_prints():
    sys.stdout = sys.__stdout__

def main():
    parser = argparse.ArgumentParser(description="GAIL Pipeline with Pre-trained Experts")
    parser.add_argument(
        "--env",
        type=str,
        default="CartPole-v0",
        choices=list(EXPERT_MAP.keys()),
        help="Environment with pre-trained expert",
    )
    parser.add_argument("--seed", type=int, default=42, help="Random seed")
    parser.add_argument("--n-envs", type=int, default=8, help="Number of parallel envs")
    parser.add_argument(
        "--demo-episodes",
        type=int,
        default=60,
        help="Number of demonstration episodes",
    )
    parser.add_argument(
        "--gail-steps",
        type=int,
        default=100000,
        help="GAIL training timesteps (min: 4096 for default config)",
    )
    parser.add_argument(
        "--demo-batch-size",
        type=int,
        default=2048,
        help="Demonstration batch size",
    )
    parser.add_argument(
        "--gen-buffer-capacity",
        type=int,
        default=512,
        help="Generator replay buffer capacity",
    )
    parser.add_argument(
        "--n-disc-updates",
        type=int,
        default=16,
        help="Number of discriminator updates per round",
    )
    
    args = parser.parse_args()
    
    print("="*60)
    print(f"GAIL Pipeline - {args.env}")
    print("="*60)
    
    gail_config = {
        "demo_batch_size": args.demo_batch_size,
        "gen_replay_buffer_capacity": args.gen_buffer_capacity,
        "n_disc_updates_per_round": args.n_disc_updates,
    }
    
    min_timesteps = args.demo_batch_size * args.n_disc_updates
    if args.gail_steps < min_timesteps:
        print(f"\n⚠️  WARNING: gail-steps ({args.gail_steps}) < minimum ({min_timesteps})")
        print(f"    Adjusting to minimum: {min_timesteps}\n")
        args.gail_steps = min_timesteps
    
    pipeline = GAILPipeline(
        env_name=args.env,
        seed=args.seed,
        n_envs=args.n_envs,
    )
    
    pipeline.run_full_pipeline(
        n_demo_episodes=args.demo_episodes,
        gail_timesteps=args.gail_steps,
        gail_config=gail_config,
    )


if __name__ == "__main__":
    main()
